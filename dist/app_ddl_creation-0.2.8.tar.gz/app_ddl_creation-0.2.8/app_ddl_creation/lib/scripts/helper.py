# ---------------- 1️⃣ Import Libraries ----------------
import os
import json
import re
from pyspark.sql import SparkSession

# Initialize Spark session (Databricks already provides 'spark', but safe for standalone)
spark = SparkSession.builder.enableHiveSupport().getOrCreate()


# ---------------- 2️⃣ Load Config ----------------
def load_config(env: str) -> dict:
    # path of current file (driver.py)
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # move up to app_ddl_creation/
    project_root = os.path.abspath(os.path.join(current_dir, "..", ".."))

    config_path = os.path.join(
        project_root, "env_config", env, "config.json"
    )

    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config not found: {config_path}")

    with open(config_path, "r") as f:
        config = json.load(f)

    return config


# ---------------- 3️⃣ Locate SQL File ----------------
def find_sql_file(base_path: str, layer: str, table_name: str) -> str:
    """
    Locate SQL file for a given table in a specific layer.
    """
    file_path = os.path.join(
        base_path,
        "Layer",      # important
        layer.lower(),
        f"{table_name}.sql"
    )

    print(file_path)

    if os.path.exists(file_path):
        print(f"✅ SQL file found: {file_path}")
        return file_path

    raise FileNotFoundError(
        f"SQL file not found: layer={layer}, table={table_name}"
    )


# ---------------- 4️⃣ Check if Table Exists ----------------
def check_table_exists(spark, catalog: str, schema: str, table: str) -> bool:
    """
    Unity Catalog safe existence check.
    Verifies both metadata AND queryability.
    """
    table = table.lower()

    result = spark.sql(
        f"SHOW TABLES IN {catalog}.{schema} LIKE '{table}'"
    ).collect()

    if not result:
        print(f"✅ Table '{catalog}.{schema}.{table}' does not exist.")
        return False

    # Extra safety: try a lightweight DESCRIBE
    try:
        spark.sql(f"DESCRIBE TABLE {catalog}.{schema}.{table}")
        print(f"⚠️ Table '{catalog}.{schema}.{table}' exists.")
        return True
    except Exception:
        print(f"⚠️ Metadata found but table not accessible: {catalog}.{schema}.{table}")
        return False


# ---------------- 5️⃣ Read SQL File ----------------
def read_sql_file(file_path: str) -> str:
    """
    Reads SQL file and returns its content as a string.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"SQL file not found: {file_path}")
    with open(file_path, "r") as f:
        return f.read()


# ---------------- 6️⃣ Parse Columns from SQL ----------------
def parse_columns_from_sql(sql_file: str) -> dict:
    """
    Parse SQL file and return a dictionary of columns with datatypes.
    Column names are converted to lowercase for comparison.
    """
    content = read_sql_file(sql_file)
    content_clean = " ".join(content.replace("\n", " ").split())

    match = re.search(
    r"create\s+table\s+(?:if\s+not\s+exists\s+)?[\w\.]+\s*\((.*?)\)\s*using",
    content_clean,
    re.IGNORECASE | re.DOTALL
)
    if not match:
        raise ValueError(f"Cannot parse columns from SQL file: {sql_file}")

    columns_str = match.group(1)
    columns = columns_str.split(",")
    col_dict = {}

    for col in columns:
        parts = col.strip().split()
        if len(parts) >= 2:
            col_name = parts[0].lower()
            col_type = normalize_datatype(parts[1])
            col_dict[col_name] = col_type

    return col_dict


# ---------------- 7️⃣ Get Table Schema ----------------
def get_table_schema(spark, table_name: str) -> dict:
    """
    Returns Spark table schema as {column_name: datatype}.
    Column names are lowercase and datatypes normalized.
    """
    df = spark.table(table_name)
    return {
        f.name.lower(): normalize_datatype(f.dataType.simpleString())
        for f in df.schema.fields
    }


# ---------------- 8️⃣ Normalize Datatype ----------------
def normalize_datatype(datatype: str) -> str:
    """
    Normalize datatypes for comparison.
    Converts to uppercase and handles common Spark type aliases.
    """
    dt = datatype.upper()
    if dt in ["STRING", "VARCHAR", "CHAR"]:
        return "STRING"
    if dt in ["INT", "INTEGER", "BIGINT", "LONG"]:
        return "INT"
    if dt in ["DOUBLE", "FLOAT", "DECIMAL"]:
        return "DOUBLE"
    # Add more rules if needed
    return dt



def detect_schema_drift(sql_columns: dict, table_schema: dict) -> dict:
    return {
        "missing_in_table": {
            col: sql_columns[col]
            for col in sql_columns
            if col not in table_schema
        },
        "type_mismatch": {
            col: {
                "sql": sql_columns[col],
                "table": table_schema[col]
            }
            for col in sql_columns
            if col in table_schema and sql_columns[col] != table_schema[col]
        },
        "extra_in_table": {
            col: table_schema[col]
            for col in table_schema
            if col not in sql_columns
        }
    }


def generate_alter_statements(table_name: str, drift: dict) -> list:
    stmts = []

    for col, dtype in drift["missing_in_table"].items():
        stmts.append(
            f"ALTER TABLE {table_name} ADD COLUMNS ({col} {dtype})"
        )

    for col, info in drift["type_mismatch"].items():
        stmts.append(
            f"ALTER TABLE {table_name} ALTER COLUMN {col} TYPE {info['sql']}"
        )

    return stmts

# ---------------- 9️⃣ Compare Schema and Alter Table ----------------
def compare_schema_and_alter(table_name: str, sql_columns: dict) -> list:
    executed_alters = []
    table_schema = get_table_schema(table_name)

    drift = detect_schema_drift(sql_columns, table_schema)

    if drift["extra_in_table"]:
        raise Exception("SQL file has fewer columns than existing table! framework will not  support DROP operations.")

    alter_stmts = generate_alter_statements(table_name, drift)

    for stmt in alter_stmts:
        print(f"🔧 Executing: {stmt}")
        spark.sql(stmt)
        executed_alters.append(stmt)

    return executed_alters

def apply_schema_changes(
    spark,
    table_name: str,
    alter_statements: list,
    env: str
):
    # No changes → do nothing
    if not alter_statements:
        print("✅ No schema changes required.")
        return

    print("⚠ Schema drift detected")

    # PROD safety guard (banking requirement)
    if env.lower() == "prod":
        raise RuntimeError(
            "Schema drift detected in PROD. Manual approval required."
        )

    # Execute only in non-prod
    for stmt in alter_statements:
        print(f"🔧 Executing: {stmt}")
        spark.sql(stmt)
