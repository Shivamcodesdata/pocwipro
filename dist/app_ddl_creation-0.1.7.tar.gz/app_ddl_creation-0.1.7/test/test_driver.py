from app_ddl_creation.lib.scripts.helper import check_table_exists

def test_check_table_exists(spark):
    spark.sql("CREATE DATABASE IF NOT EXISTS test_db")
    spark.sql("CREATE TABLE test_db.sample (id INT)")

    assert check_table_exists(spark, "test_db", "sample") is True
    assert check_table_exists(spark, "test_db", "missing") is False
