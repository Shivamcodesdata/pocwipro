from app_ddl_creation.lib.scripts.helper import (
    find_sql_file,
    read_sql_file,
    parse_columns_from_sql
)

def test_find_sql_file(tmp_path):
    sql_dir = tmp_path / "bronze"
    sql_dir.mkdir()
    file = sql_dir / "sample.sql"
    file.write_text("select * from test")

    result = find_sql_file(str(tmp_path), "bronze", "sample")
    assert result.endswith("sample.sql")


def test_read_sql_file(tmp_path):
    sql_file = tmp_path / "test.sql"
    sql_file.write_text("select id, name from table")

    content = read_sql_file(str(sql_file))
    assert "select id" in content


def test_parse_columns_from_sql():
    sql = """
        CREATE TABLE test (
            id INT,
            name STRING,
            amount DOUBLE
        )
    """
    cols = parse_columns_from_sql(sql)

    assert cols == ["id", "name", "amount"]
